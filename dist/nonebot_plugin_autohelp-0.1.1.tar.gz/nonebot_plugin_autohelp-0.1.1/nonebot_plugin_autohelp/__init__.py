"""Autogenerate response to commands /help !help help 菜单 caidan /i.

For more info on usage:
/help -h
"""
__version__ = "0.1.1"
from .nonebot_plugin_autohelp import nonebot_plugin_autohelp

__all__ = ("nonebot_plugin_autohelp",)
